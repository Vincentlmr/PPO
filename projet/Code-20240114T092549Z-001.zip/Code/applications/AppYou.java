package applications;
import lib.*;
import exceptions.*;
import java.io.*;
import java.util.*;

//Affichage des cases selon l'ordre croissant des valeurs (valeurs null mises à la fin)
public class AppYou{

    public static void main(String argv[]) {
        Grille gril = new Grille(); // on crée une grille
        List<Case> cas= new ArrayList<Case>();// et une liste de cases
        
        //chargement de la grille sérialisée
        try {
             gril.load("bob.bin");
         } catch(IOException ie) {
            System.out.println(ie.getMessage());
            ie.printStackTrace();
         }
         catch(ClassNotFoundException cl) {
            System.out.println(cl.getMessage());
            cl.printStackTrace();
         }
         
         //Affichage des cases
         cas=gril.getCasesOrdreCroissant(); // on récupère la liste des cases dans l'ordre croissant
         for(int i=0; i<cas.size();i++){
            System.out.println(cas.get(i).toString()); // on affiche pour chaques case son "nom" et sa valeur
        }
    }
}

